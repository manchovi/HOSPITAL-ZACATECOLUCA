<?php
/*** Provee las constantes para conectarse a la base de datos Mysql. ***/
 
define("HOSTNAME", "localhost");               // Nombre del host
define("DATABASE", "mjgl_db_biomedic_2019");              // Nombre de la base de datos
define("USERNAME", "mjgl_usehospital");              // Nombre del usuario
define("PASSWORD", "hospital2019_");              // Nombre de la constrasena

?>