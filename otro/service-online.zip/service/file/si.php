<?php
//$txt = utf8_decode($txt);  COLOCAR ESTA LINEA AL ARCHIVO FPDF.php en la línea 615.

?>